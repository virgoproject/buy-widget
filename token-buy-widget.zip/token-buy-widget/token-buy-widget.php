<?php
/**
* Plugin Name: Token Buy Widget
* Plugin URI: https://virgo.net/widget/
* Description: Permit cryptocurrency project owners to sell their token directly from their website. Supports 10+ fiat payment methods.
* Version: 1.1
* Author: Virgo
* Author URI: https://virgo.net/
* License: GPLv2 or later
**/


/**
* Buy widget shortcode [display_buy_widget]
**/
function vgoBuy_shortcode(){
    $options = get_option( 'vgoBuy_settings_options' );

    $chainID = "56";
    if($options != false && array_key_exists('chainID', $options))
        $chainID = esc_attr( $options['chainID'] );

    $address = "0xFb526228ff1C019E4604C7e7988C097D96bD5b70";
    if($options != false && array_key_exists('address', $options))
        $address = esc_attr( $options['address'] );

    $color = "#B71C8E";
    if($options != false && array_key_exists('color', $options))
        $color = esc_attr( $options['color'] );

    $color = str_replace("#", "", $color);

    $logo = "";
    if($options != false && array_key_exists('logo', $options))
        $logo = base64_encode(esc_attr( $options['logo'] ));

    return '<iframe src="https://widget.virgo.net/popup.html?chainID='.$chainID.'&contract='.$address.'&themeColor='.$color.'&logo='.$logo.'&showmode=true" allow="clipboard-read; clipboard-write" style="border: none; width: 424px; height: 523px;"></iframe>';
}
add_shortcode( 'display_buy_widget', 'vgoBuy_shortcode' );


/**
* Insert widget code to footer
**/
function vgoBuy_addWidgetToFooter() {
    $options = get_option( 'vgoBuy_settings_options' );

    if($options == false || (array_key_exists('enabled', $options) && $options['enabled'] != "true")){
        return;
    }

    $chainID = "56";
    if($options != false && array_key_exists('chainID', $options))
        $chainID = esc_attr( $options['chainID'] );

    $address = "0xFb526228ff1C019E4604C7e7988C097D96bD5b70";
    if($options != false && array_key_exists('address', $options))
        $address = esc_attr( $options['address'] );

    $color = "#B71C8E";
    if($options != false && array_key_exists('color', $options))
        $color = esc_attr( $options['color'] );

    $color = str_replace("#", "", $color);

    $horizontalPadding = "1em";
    if($options != false && array_key_exists('horizontalPadding', $options))
        $horizontalPadding = esc_attr( $options['horizontalPadding'] );

    $verticalPadding = "0.375em";
    if($options != false && array_key_exists('verticalPadding', $options))
        $verticalPadding = esc_attr( $options['verticalPadding'] );

    $borderRadius = "0.375em";
    if($options != false && array_key_exists('borderRadius', $options))
        $borderRadius = esc_attr( $options['borderRadius'] );

    $horizontalOffset = "16px";
    if($options != false && array_key_exists('horizontalOffset', $options))
        $horizontalOffset = esc_attr( $options['horizontalOffset'] );

    $verticalOffset = "16px";
    if($options != false && array_key_exists('verticalOffset', $options))
        $verticalOffset = esc_attr( $options['verticalOffset'] );

    $position = "right";
    if($options != false && array_key_exists('position', $options))
        $position = esc_attr( $options['position'] );

    $text = "Buy [tokenSymbol]";
    if($options != false && array_key_exists('text', $options))
        $text = esc_attr( $options['text'] );

    $logo = "";
    if($options != false && array_key_exists('logo', $options))
        $logo = esc_attr( $options['logo'] );

    echo '<script src="https://widget.virgo.net/js/widget.js"></script>
          <script>
              virgo_initBuyBtn({chainID: "' . $chainID . '", contract: "' . $address . '", themeColor: "' . $color . '", horizontalPadding: "' . $horizontalPadding .
              '", verticalPadding: "' . $verticalPadding . '", borderRadius: "' . $borderRadius. '", borderRadius: "' . $borderRadius .
              '", horizontalOffset: "' . $horizontalOffset . '", verticalOffset: "' . $verticalOffset . '", position: "' . $position .
              '", text: "' . $text . '", logo: "' . $logo . '"})
          </script>';
}
add_action('wp_footer', 'vgoBuy_addWidgetToFooter');


/**
* Admin menu
**/

//required scripts for media uploader
function vgoBuy_settings_scripts() {
    wp_enqueue_media();
    wp_register_script('token-buy-widget-admin-js', WP_PLUGIN_URL.'/token-buy-widget/admin.js', array('jquery'));
    wp_enqueue_script('token-buy-widget-admin-js');
}
add_action('admin_enqueue_scripts', 'vgoBuy_settings_scripts');

//add admin menu
add_action('admin_menu', 'vgoBuy_addMenu');

function vgoBuy_addMenu() {
      add_menu_page(
          'Token Buy Widget',
          'Token Buy widget',
          'activate_plugins',
          'vgo_buy_widget',
          'vgoBuy_settings',
          'dashicons-welcome-widgets-menus'
      );
}

//admin menu display
function vgoBuy_settings() {
        ?>
        <h2>Token Buy Widget Settings</h2>
        <form action="options.php" method="post">
            <?php
            settings_fields( 'vgoBuy_settings_options' );
            do_settings_sections( 'vgoBuy_settings_fields' ); ?>
            <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e( 'Save' ); ?>" />
            <?php
                if(isset($_GET['settings-updated'])){
                    echo "<p style='color: green'>Settings updated!</p>";
                }
            ?>
        </form>
        <?php
}

function chainIDToTicker($chainID){
    switch($chainID){
        case "1":
            return "ETH";
        case "56":
            return "BNB";
        case "137":
            return "MATIC";
        default:
            return "NONE";
    }
}

//register options
function vgoBuy_register_settings() {
    register_setting( 'vgoBuy_settings_options', 'vgoBuy_settings_options', 'vgoBuy_settings_options_validate' );
    add_settings_section( 'main_settings', 'Main Settings', 'vgoBuy_settings_section_main', 'vgoBuy_settings_fields' );

    add_settings_field( 'vgoBuy_setting_enabled', 'Display buy button', 'vgoBuy_setting_enabled', 'vgoBuy_settings_fields', 'main_settings' );
    add_settings_field( 'vgoBuy_setting_chainID', 'Chain', 'vgoBuy_setting_chainID', 'vgoBuy_settings_fields', 'main_settings' );
    add_settings_field( 'vgoBuy_setting_address', 'Contract address', 'vgoBuy_setting_address', 'vgoBuy_settings_fields', 'main_settings' );

    add_settings_section( 'style_settings', 'Customize', 'vgoBuy_settings_section_style', 'vgoBuy_settings_fields' );

    add_settings_field( 'vgoBuy_setting_color', 'Theme color', 'vgoBuy_setting_color', 'vgoBuy_settings_fields', 'style_settings' );
    add_settings_field( 'vgoBuy_setting_horizontalPadding', 'Horizontal padding', 'vgoBuy_setting_horizontalPadding', 'vgoBuy_settings_fields', 'style_settings' );
    add_settings_field( 'vgoBuy_setting_verticalPadding', 'Vertical padding', 'vgoBuy_setting_verticalPadding', 'vgoBuy_settings_fields', 'style_settings' );
    add_settings_field( 'vgoBuy_setting_borderRadius', 'BorderRadius', 'vgoBuy_setting_borderRadius', 'vgoBuy_settings_fields', 'style_settings' );
    add_settings_field( 'vgoBuy_setting_horizontalOffset', 'Horizontal Offset', 'vgoBuy_setting_horizontalOffset', 'vgoBuy_settings_fields', 'style_settings' );
    add_settings_field( 'vgoBuy_setting_verticalOffset', 'Vertical Offset', 'vgoBuy_setting_verticalOffset', 'vgoBuy_settings_fields', 'style_settings' );
    add_settings_field( 'vgoBuy_setting_position', 'Position', 'vgoBuy_setting_position', 'vgoBuy_settings_fields', 'style_settings' );
    add_settings_field( 'vgoBuy_setting_text', 'Button text', 'vgoBuy_setting_text', 'vgoBuy_settings_fields', 'style_settings' );
    add_settings_field( 'vgoBuy_setting_logo', 'Token logo', 'vgoBuy_setting_logo', 'vgoBuy_settings_fields', 'style_settings' );
}
add_action( 'admin_init', 'vgoBuy_register_settings' );

function vgoBuy_settings_options_validate( $input ) {
    return $input;
}

function vgoBuy_settings_section_main() {
    echo '<p>Here you can set all the options for using the widget</p>';
}

function vgoBuy_settings_section_style() {
    echo '<p>Customize the widget style</p>';
}

function vgoBuy_setting_enabled() {
    $options = get_option( 'vgoBuy_settings_options' );

    $enabled = "false";
    if($options != false && array_key_exists('enabled', $options))
        $enabled = esc_attr( $options['enabled'] );

    echo '<select name="vgoBuy_settings_options[enabled]" id="vgoBuy_setting_enabled">
              <option value="true"';

    if($enabled == "true")
            echo " selected";
        echo '>Enabled</option>
                  <option value="false"';
        if($enabled == "false")
            echo " selected";
        echo '>Disabled</option></select>';

}

function vgoBuy_setting_chainID() {
    $options = get_option( 'vgoBuy_settings_options' );

    $chainID = "56";
    if($options != false && array_key_exists('chainID', $options))
        $chainID = esc_attr( $options['chainID'] );

    echo '<select name="vgoBuy_settings_options[chainID]" id="vgoBuy_setting_chainID">
              <option value="1"';
    if($chainID == "1")
        echo " selected";
    echo '>Ethereum</option>
              <option value="56"';
    if($chainID == "56")
        echo " selected";
    echo '>Binance Smart Chain</option>
              <option value="137"';
    if($chainID == "137")
        echo " selected";
    echo '>Polygon</option>
          </select>';
}

function vgoBuy_setting_address() {
    $options = get_option( 'vgoBuy_settings_options' );

    $address = "0xFb526228ff1C019E4604C7e7988C097D96bD5b70";
    if($options != false && array_key_exists('address', $options))
        $address = esc_attr( $options['address'] );

    echo "<input id='vgoBuy_setting_address' name='vgoBuy_settings_options[address]' type='text' value='" . $address . "' style='width: 46ch;'/>";
}

function vgoBuy_setting_color() {
    $options = get_option( 'vgoBuy_settings_options' );

    $color = "#B71C8E";
    if($options != false && array_key_exists('color', $options))
        $color = esc_attr( $options['color'] );

    echo "<input id='vgoBuy_setting_color' name='vgoBuy_settings_options[color]' type='color' value='" . $color . "'/>";
}

function vgoBuy_setting_horizontalPadding() {
    $options = get_option( 'vgoBuy_settings_options' );

    $horizontalPadding = "1em";
    if($options != false && array_key_exists('horizontalPadding', $options))
        $horizontalPadding = esc_attr( $options['horizontalPadding'] );

    echo "<input id='vgoBuy_setting_horizontalPadding' name='vgoBuy_settings_options[horizontalPadding]' type='text' value='" . $horizontalPadding . "'/>";
}

function vgoBuy_setting_verticalPadding() {
    $options = get_option( 'vgoBuy_settings_options' );

    $verticalPadding = "0.375em";
    if($options != false && array_key_exists('verticalPadding', $options))
        $verticalPadding = esc_attr( $options['verticalPadding'] );

    echo "<input id='vgoBuy_setting_verticalPadding' name='vgoBuy_settings_options[verticalPadding]' type='text' value='" . $verticalPadding . "'/>";
}

function vgoBuy_setting_borderRadius() {
    $options = get_option( 'vgoBuy_settings_options' );

    $borderRadius = "0.375em";
    if($options != false && array_key_exists('borderRadius', $options))
        $borderRadius = esc_attr( $options['borderRadius'] );

    echo "<input id='vgoBuy_setting_borderRadius' name='vgoBuy_settings_options[borderRadius]' type='text' value='" . $borderRadius . "'/>";
}

function vgoBuy_setting_horizontalOffset() {
    $options = get_option( 'vgoBuy_settings_options' );

    $horizontalOffset = "16px";
    if($options != false && array_key_exists('horizontalOffset', $options))
        $horizontalOffset = esc_attr( $options['horizontalOffset'] );

    echo "<input id='vgoBuy_setting_horizontalOffset' name='vgoBuy_settings_options[horizontalOffset]' type='text' value='" . $horizontalOffset . "'/>";
}

function vgoBuy_setting_verticalOffset() {
    $options = get_option( 'vgoBuy_settings_options' );

    $verticalOffset = "16px";
    if($options != false && array_key_exists('verticalOffset', $options))
        $verticalOffset = esc_attr( $options['verticalOffset'] );

    echo "<input id='vgoBuy_setting_verticalOffset' name='vgoBuy_settings_options[verticalOffset]' type='text' value='" . $verticalOffset . "'/>";
}

function vgoBuy_setting_position() {
    $options = get_option( 'vgoBuy_settings_options' );

    $position = "right";
    if($options != false && array_key_exists('position', $options))
        $position = esc_attr( $options['position'] );

    echo '<select name="vgoBuy_settings_options[position]" id="vgoBuy_setting_position">
              <option value="left"';
    if($position == "left")
        echo " selected";
    echo '>Left</option>
              <option value="center"';
    if($position == "center")
        echo " selected";
    echo '>Center</option>
              <option value="right"';
    if($position == "right")
        echo " selected";
    echo '>Right</option>
          </select>';
}

function vgoBuy_setting_text() {
    $options = get_option( 'vgoBuy_settings_options' );

    $text = "Buy [tokenSymbol]";
    if($options != false && array_key_exists('text', $options))
        $text = esc_attr( $options['text'] );

    echo "<input id='vgoBuy_setting_text' name='vgoBuy_settings_options[text]' type='text' value='" . $text . "'/>";
    echo "<p>[tokenSymbol] is replaced by your token's symbol, ex: VGO</p>";
}

function vgoBuy_setting_logo() {
    $options = get_option( 'vgoBuy_settings_options' );

    $logo = "";
    if($options != false && array_key_exists('logo', $options))
        $logo = esc_attr( $options['logo'] );

    echo "<input id='vgoBuy_setting_logo_disp' name='vgoBuy_setting_logo_disp' type='text' value='" . $logo . "' disabled='true'/>";
    echo "<input id='vgoBuy_setting_logo' name='vgoBuy_settings_options[logo]' type='hidden' value='" . $logo . "'/>";
    echo "<input id='upload_image_button' class='button' type='button' value='Choose a file' />";
}


/**
*
* Statistics
*
**/

// Function that outputs the contents of the dashboard widget
function vgoBuy_dashboard_widget( $post, $callback_args ) {
    ?>
    <p>Last 24h</p>
    <div class="vgoBuy_col">
        <b>Views</b>
        <p id="vgoBuy_views">0</p>
    </div>
    <div class="vgoBuy_col">
        <b>Orders</b>
        <p id="vgoBuy_orders">0</p>
    </div>
    <div class="vgoBuy_col">
        <b>Completed</b>
        <p id="vgoBuy_completed">0</p>
    </div>
    <style>
        .vgoBuy_col {
            width: 32%;
            display: inline-block;
        }
    </style>
    <?php

     $options = get_option( 'vgoBuy_settings_options' );

     $chainID = "";
     if($options != false && array_key_exists('chainID', $options))
         $chainID = esc_attr( $options['chainID'] );

     $address = "";
     if($options != false && array_key_exists('address', $options))
         $address = esc_attr( $options['address'] );

     if($chainID != "" && $address != ""){
     ?>
    <script>
        const date = new Date().toISOString().split("T")[0].replaceAll("-", "")
        fetch("https://widget.virgo.net/api/stats/<?php echo chainIDToTicker($chainID); ?>.<?php echo $address; ?>/"+date)
        .then(res => res.json())
        .then(json => {
            if(json == false) return

            document.getElementById("vgoBuy_views").innerHTML = json.views
            document.getElementById("vgoBuy_orders").innerHTML = json.orderCount
            document.getElementById("vgoBuy_completed").innerHTML = json.completedOrdersCount
        })
    </script>
    <?php
     }
}

// Function used in the action hook
function vgoBuy_add_dashboard_widget() {
    wp_add_dashboard_widget('dashboard_widget', 'Token buy widget statistics', 'vgoBuy_dashboard_widget');
}

// Register the new dashboard widget with the 'wp_dashboard_setup' action
add_action('wp_dashboard_setup', 'vgoBuy_add_dashboard_widget' );

?>
