=== Token Buy Widget ===
Contributors: virgosas
Tags:
Requires at least: 4.7
Tested up to: 6.1.1
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Permit cryptocurrency project owners to sell their token directly from their website. Supports 10+ fiat payment methods.

== Description ==

Virgo Widget - Sell your cryptocurrency on your website. Simple, Fast, and Secure!

Discover Virgo Widget, the essential tool to sell your cryptocurrency directly on your website quickly! Revolutionize the user experience by making the purchase of your cryptocurrency more accessible, faster, more personalized, more secure, and less expensive. Make buying easier and build trust in your brand. Virgo Widget is an essential tool to improve the user experience.

Easing access to your token is essential for its success. Still, classical solutions like centralized exchanges are often expensive and cumbersome for users. We created Virgo Widget to end that pain.

Download our plugin, configure it in a few clicks, and voilà!
Your token will become buyable directly on your website via a small popup at a corner. Your users will be able to choose between 150+ crypto-assets, as well as fiat payment methods such as Visa or Mastercard, to become one of your holders!

* Simple and fast: Only 3 steps are necessary for the user to buy and receive your crypto-currency; The easier the process, the better it converts.

* Customization: Virgo widget can be customized to match the look of your website perfectly. You can easily change colors, sizes, and alignments to make it feel genuine.

* Low Transaction Fees: The Virgo Widget offers low transaction fees to allow users to buy your cryptocurrency at competitive prices.

== Frequently Asked Questions ==

= Is my token compatible with this plugin? =

As long your token is either on Ethereum, Polygon or Binance Chain and is buyable on Uniswap V3 / PancakeSwap, then yes.

= Which payment methods are supported? =

Users can buy your token with 150+ tokens from Ethereum, Polygon and BSC; Regardless of your origin chain. We also support fiat payments with Visa/Mastercard, bank transfers, Apple Pay, and more.

== Changelog ==

= 1.0 =
* Initial version, Virgo Widget is compatible with Ethereum, Polygon, and The Binance Smart Chain.
